# @starwind-ui/core

## 1.16.2

## 1.16.1

### Patch Changes

- 43a7435: fix carousel previous and next buttons
- ece15f2: refactor: move data-slot attributes before spread props in dynamic tag components to support data-slot overrides

## 1.16.0

### Minor Changes

- 6a3b754: feat: add popover component
- 7bc43d2: feat: add input-group component
- a2153f5: feat: add dropdown sub-menu support
- f8953e5: feat: add native-select component

### Patch Changes

- 4ea7955: refactor: spread props before data-slot attribute to enable data-slot overrides
- d865158: feat: update sidebar to support new tooltip implementation
- 0bf0403: feat: improve tooltip positioning

## 1.15.5

## 1.15.4

### Patch Changes

- af156c5: feat(card): add "sm" card variant and improve styling to more closely match the shadcn implementation

## 1.15.3

## 1.15.2

### Patch Changes

- c997e6f: fix(input-otp): focus hidden input on click to automatically open keyboards on mobile devices. Also always focus the next empty index
- 17d0877: fix(select): selections with the `spacebar` key no longer cause the page to scroll

## 1.15.0

### Minor Changes

- 2a7b70e: feat: add prose component
- c667fb9: feat: add input-otp component
- eece2cc: feat: add theme toggle component
- b4bd93d: feat: add sidebar component

### Patch Changes

- 225ceb1: Update tooltip positioning to work with the sidebar component. It now uses fixed positioning with javascript placement calculations.
- efa8569: style: update button and badge styling (related to #99)

## 1.14.0

### Patch Changes

- 05ad2c7: feat(select): add guard for programmatic selection to prevent potential infinite loops

## 1.13.0

### Minor Changes

- 3a1a86a: feat: add slider component
- e574ea6: feat: add video component
- db9b710: feat: add toast component
- 4105668: feat: add image component

### Patch Changes

- 708806e: feat(dialog): improve nested dialog animation and functionality
- c3e979a: style: add class "font-heading" to component headings to enable global header font updates
- 0662058: Add `starwind:init` event listener to enable initialization of additional starwind components loaded after an initial page load, such as when using server islands
- 5cfefe4: style(accordion): update the opening animation so that it does not play on initial accordion load
- 03d5d9a: feat: improve behavior and styling of nested dialogs

## 1.12.4

### Patch Changes

- 13b7c60: Unlock package versions for potential dependency bug fixes

## 1.12.2

## 1.12.1

### Patch Changes

- f7ad6e1: style: add aria-invalid styling for form related components
- 88e2d11: feat(select): enable "required" attribute for form handling purposes

## 1.12.0

### Minor Changes

- 2320eaf: feat: add button-group component
- fb5651f: feat: add combobox component leveraging the select component
- 7773330: feat: add toggle component

### Patch Changes

- 7b43fcb: feat: add "size" prop to `SelectTrigger` and `SelectContent`, implement `SelectSearch` for a combobox-like implementation, and improve select component styling
- ce55d46: fix: alert dialog and dropdown components no longer risk having a class of "undefined"
- 64c1c3a: fix: button group now better handles select and dropdowns within the group
- 5121926: feat(pagination): add size prop to PaginationEllipsis, and adjust PaginationNext and PaginationPrevious to use button variant props for sizes

## 1.11.2

### Patch Changes

- 33dd20a: chore: update registry component versions

## 1.11.1

### Patch Changes

- e2e411c: Avatar: add ability to pass additional attributes to components
- b255995: Removed debug logging statements from Dropdown and RadioGroup components

## 1.11.0

### Minor Changes

- 6793ef1: Add Kbd component for keyboard shortcuts

### Patch Changes

- c0a2da8: feat: add slots for various components to enable easier styling, including accordion, alert-dialog, breadcrumb, carousel, dialog, pagination, radio-group, select, and sheet components

## 1.10.1

### Patch Changes

- eaaec1b: simplify default accordion styling to enable easier custom styling

## 1.10.0

### Minor Changes

- 1f83bc0: add item component
- bdcbfe3: add spinner component
- 96de92c: Update various component styles and focus states
- 9261789: Add new separator component
- 680f584: add new aspect-ratio component

## 1.9.0

### Minor Changes

- ef55ef6: add a "data-slot" for every component to enable global styling updates
- b83b5d5: feat: add variant function exports for all components to enable reusing styling in your own files
- 5f3769c: feat: add alert-dialog component
- e8e9a39: add carousel component leveraging embla-carousel
- 9a5187d: Add sheet component

### Patch Changes

- 432168d: Dialog trigger now correctly preserves its default styling while appending user-provided class names when used as a child component. This ensures custom styles work without overriding core styles and maintains consistent appearance across usage patterns. No API changes; improved compatibility with theming and design systems.
- f9c3fa3: various fixes to alert-dialog, alert, and dialog components

## 1.8.0

### Patch Changes

- - Initial changeset setup.
